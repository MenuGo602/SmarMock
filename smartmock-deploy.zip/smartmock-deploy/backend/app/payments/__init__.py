from .router import router as payme_router

__all__ = ["payme_router"]
