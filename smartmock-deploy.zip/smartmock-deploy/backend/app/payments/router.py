"""
Payme Merchant API webhook — bitta POST endpoint orqali JSON-RPC so'rovlarni
qabul qiladi: CheckPerformTransaction, CreateTransaction, PerformTransaction,
CancelTransaction, CheckTransaction, GetStatement.

Payme administrator panelida ushbu endpointni "Kassa havolasi" sifatida
ko'rsating, masalan: https://api.yourdomain.com/api/v1/payments/payme
"""
import base64
import time

from fastapi import APIRouter, Depends, Header, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings  # noqa  ← PAYME_KEY, PAYME_ACCOUNT_FIELD shu yerda
from app.database import get_db  # noqa  ← loyihangizdagi DB session dependency

from .errors import (
    ERROR_ACCOUNT_NOT_FOUND,
    ERROR_AUTH_FAILED,
    ERROR_CANT_PERFORM,
    ERROR_INVALID_AMOUNT,
    ERROR_METHOD_NOT_FOUND,
    ERROR_ORDER_STATE_INVALID,
    ERROR_TRANSACTION_NOT_FOUND,
    rpc_error,
    rpc_result,
)
from .models import OrderStatus, PaymeTransaction, SubscriptionOrder, TxState

router = APIRouter(prefix="/payments/payme", tags=["payme"])

TRANSACTION_TIMEOUT_MS = 12 * 60 * 1000  # Payme talabi: 12 daqiqa


def _check_auth(authorization: str | None) -> bool:
    """Payme so'rovlari Basic Auth bilan keladi: login=Paycom, parol=PAYME_KEY."""
    if not authorization or not authorization.startswith("Basic "):
        return False
    try:
        decoded = base64.b64decode(authorization.split(" ", 1)[1]).decode()
        login, _, key = decoded.partition(":")
        return login == "Paycom" and key == settings.PAYME_KEY
    except Exception:
        return False


async def _get_order(db: AsyncSession, order_id: int) -> SubscriptionOrder | None:
    res = await db.execute(select(SubscriptionOrder).where(SubscriptionOrder.id == order_id))
    return res.scalar_one_or_none()


async def _get_tx(db: AsyncSession, payme_id: str) -> PaymeTransaction | None:
    res = await db.execute(select(PaymeTransaction).where(PaymeTransaction.payme_id == payme_id))
    return res.scalar_one_or_none()


async def _resolve_order(db: AsyncSession, params: dict, req_id):
    account = params.get("account", {})
    raw_id = account.get(settings.PAYME_ACCOUNT_FIELD)
    try:
        order_id = int(raw_id)
    except (TypeError, ValueError):
        return None, rpc_error(
            req_id, ERROR_ACCOUNT_NOT_FOUND,
            "Buyurtma topilmadi", "Заказ не найден", "Order not found",
        )

    order = await _get_order(db, order_id)
    if order is None:
        return None, rpc_error(
            req_id, ERROR_ACCOUNT_NOT_FOUND,
            "Buyurtma topilmadi", "Заказ не найден", "Order not found",
        )
    return order, None


@router.post("")
async def payme_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
    authorization: str | None = Header(default=None),
):
    body = await request.json()
    req_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    if not _check_auth(authorization):
        return rpc_error(
            req_id, ERROR_AUTH_FAILED,
            "Avtorizatsiya xato", "Ошибка авторизации", "Authorization error",
        )

    handlers = {
        "CheckPerformTransaction": _check_perform_transaction,
        "CreateTransaction": _create_transaction,
        "PerformTransaction": _perform_transaction,
        "CancelTransaction": _cancel_transaction,
        "CheckTransaction": _check_transaction,
        "GetStatement": _get_statement,
    }
    handler = handlers.get(method)
    if handler is None:
        return rpc_error(
            req_id, ERROR_METHOD_NOT_FOUND,
            "Metod topilmadi", "Метод не найден", "Method not found",
        )

    return await handler(db, req_id, params)


async def _check_perform_transaction(db, req_id, params):
    order, err = await _resolve_order(db, params, req_id)
    if err:
        return err

    if order.status != OrderStatus.PENDING:
        return rpc_error(
            req_id, ERROR_ORDER_STATE_INVALID,
            "Buyurtma holati noto'g'ri", "Неверный статус заказа", "Invalid order state",
        )

    if int(params.get("amount", 0)) != order.amount:
        return rpc_error(
            req_id, ERROR_INVALID_AMOUNT,
            "Summa noto'g'ri", "Неверная сумма", "Invalid amount",
        )

    return rpc_result(req_id, {"allow": True})


async def _create_transaction(db, req_id, params):
    order, err = await _resolve_order(db, params, req_id)
    if err:
        return err

    payme_id = params["id"]
    amount = int(params.get("amount", 0))

    existing = await _get_tx(db, payme_id)
    if existing:
        if existing.state != TxState.CREATED.value:
            return rpc_error(
                req_id, ERROR_CANT_PERFORM,
                "Tranzaksiya holati mos kelmaydi", "Несоответствие состояния", "Transaction state mismatch",
            )
        return rpc_result(req_id, {
            "create_time": existing.create_time,
            "transaction": str(existing.id),
            "state": existing.state,
        })

    if order.status != OrderStatus.PENDING:
        return rpc_error(
            req_id, ERROR_ORDER_STATE_INVALID,
            "Buyurtma holati noto'g'ri", "Неверный статус заказа", "Invalid order state",
        )

    if amount != order.amount:
        return rpc_error(
            req_id, ERROR_INVALID_AMOUNT,
            "Summa noto'g'ri", "Неверная сумма", "Invalid amount",
        )

    now_ms = int(time.time() * 1000)
    tx = PaymeTransaction(
        payme_id=payme_id,
        order_id=order.id,
        amount=amount,
        state=TxState.CREATED.value,
        create_time=now_ms,
    )
    db.add(tx)
    await db.commit()
    await db.refresh(tx)

    return rpc_result(req_id, {
        "create_time": tx.create_time,
        "transaction": str(tx.id),
        "state": tx.state,
    })


async def _perform_transaction(db, req_id, params):
    payme_id = params["id"]
    tx = await _get_tx(db, payme_id)
    if tx is None:
        return rpc_error(
            req_id, ERROR_TRANSACTION_NOT_FOUND,
            "Tranzaksiya topilmadi", "Транзакция не найдена", "Transaction not found",
        )

    if tx.state == TxState.PERFORMED.value:
        return rpc_result(req_id, {
            "transaction": str(tx.id),
            "perform_time": tx.perform_time,
            "state": tx.state,
        })

    if tx.state != TxState.CREATED.value:
        return rpc_error(
            req_id, ERROR_CANT_PERFORM,
            "Amalni bajarib bo'lmaydi", "Невозможно выполнить операцию", "Cannot perform operation",
        )

    if int(time.time() * 1000) - tx.create_time > TRANSACTION_TIMEOUT_MS:
        tx.state = TxState.CANCELLED_AFTER_CREATE.value
        tx.reason = 4
        tx.cancel_time = int(time.time() * 1000)
        await db.commit()
        return rpc_error(
            req_id, ERROR_CANT_PERFORM,
            "Tranzaksiya vaqti tugagan", "Время транзакции истекло", "Transaction expired",
        )

    tx.state = TxState.PERFORMED.value
    tx.perform_time = int(time.time() * 1000)
    await db.commit()

    order = await _get_order(db, tx.order_id)
    order.status = OrderStatus.PAID
    await db.commit()

    # TODO: shu yerda foydalanuvchi obunasini faollashtiring/uzaytiring, masalan:
    # await activate_subscription(db, order.user_id, order.plan_id)

    return rpc_result(req_id, {
        "transaction": str(tx.id),
        "perform_time": tx.perform_time,
        "state": tx.state,
    })


async def _cancel_transaction(db, req_id, params):
    payme_id = params["id"]
    reason = params.get("reason")
    tx = await _get_tx(db, payme_id)
    if tx is None:
        return rpc_error(
            req_id, ERROR_TRANSACTION_NOT_FOUND,
            "Tranzaksiya topilmadi", "Транзакция не найдена", "Transaction not found",
        )

    if tx.state == TxState.CREATED.value:
        tx.state = TxState.CANCELLED_AFTER_CREATE.value
    elif tx.state == TxState.PERFORMED.value:
        tx.state = TxState.CANCELLED_AFTER_PERFORM.value
        order = await _get_order(db, tx.order_id)
        order.status = OrderStatus.CANCELLED
        # TODO: kerak bo'lsa obunani shu yerda bekor qiling

    tx.reason = reason
    tx.cancel_time = int(time.time() * 1000)
    await db.commit()

    return rpc_result(req_id, {
        "transaction": str(tx.id),
        "cancel_time": tx.cancel_time,
        "state": tx.state,
    })


async def _check_transaction(db, req_id, params):
    payme_id = params["id"]
    tx = await _get_tx(db, payme_id)
    if tx is None:
        return rpc_error(
            req_id, ERROR_TRANSACTION_NOT_FOUND,
            "Tranzaksiya topilmadi", "Транзакция не найдена", "Transaction not found",
        )

    return rpc_result(req_id, {
        "create_time": tx.create_time,
        "perform_time": tx.perform_time,
        "cancel_time": tx.cancel_time,
        "transaction": str(tx.id),
        "state": tx.state,
        "reason": tx.reason,
    })


async def _get_statement(db, req_id, params):
    from_ts = int(params.get("from", 0))
    to_ts = int(params.get("to", 0))

    res = await db.execute(
        select(PaymeTransaction).where(
            PaymeTransaction.create_time >= from_ts,
            PaymeTransaction.create_time <= to_ts,
        )
    )
    txs = res.scalars().all()

    return rpc_result(req_id, {
        "transactions": [
            {
                "id": tx.payme_id,
                "time": tx.create_time,
                "amount": tx.amount,
                "account": {settings.PAYME_ACCOUNT_FIELD: str(tx.order_id)},
                "create_time": tx.create_time,
                "perform_time": tx.perform_time,
                "cancel_time": tx.cancel_time,
                "transaction": str(tx.id),
                "state": tx.state,
                "reason": tx.reason,
            }
            for tx in txs
        ]
    })
