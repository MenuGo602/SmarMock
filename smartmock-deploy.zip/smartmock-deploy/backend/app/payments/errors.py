"""
Payme Merchant API — JSON-RPC xato kodlari va javob shakllantiruvchilar.
Spetsifikatsiya: https://developer.help.paycom.uz/
"""

ERROR_INVALID_AMOUNT = -31001
ERROR_TRANSACTION_NOT_FOUND = -31003
ERROR_CANT_PERFORM = -31008
ERROR_ACCOUNT_NOT_FOUND = -31050
ERROR_ORDER_STATE_INVALID = -31051
ERROR_AUTH_FAILED = -32504
ERROR_METHOD_NOT_FOUND = -32601
ERROR_INVALID_REQUEST = -32600
ERROR_PARSE_ERROR = -32700


def rpc_result(req_id, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def rpc_error(req_id, code: int, uz: str, ru: str, en: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": {"uz": uz, "ru": ru, "en": en}},
    }
