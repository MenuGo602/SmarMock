"""
Payme hosted checkout (kassa) link generatori + order yaratish.

PLAN_PRICES — vaqtinchalik joy egallovchi narxlar (tiyin, 1 so'm = 100 tiyin).
Productionda buni mavjud `Plan` jadvalingizdan o'qishga almashtiring.
"""
import base64

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings  # noqa  ← PAYME_* sozlamalar shu yerda bo'lishi kerak
from .models import OrderStatus, SubscriptionOrder

# TODO: bularni `Plan` jadvalingizdagi haqiqiy narxlar bilan almashtiring
PLAN_PRICES = {
    "pro": 14_500_00,       # 145 000 so'm
    "premium": 29_500_00,   # 295 000 so'm
}


def build_checkout_url(order_id: int, amount_tiyin: int, return_url: str | None = None) -> str:
    """Payme GET-init usulidagi checkout havolasini yaratadi."""
    params = (
        f"m={settings.PAYME_MERCHANT_ID};"
        f"ac.{settings.PAYME_ACCOUNT_FIELD}={order_id};"
        f"a={amount_tiyin}"
    )
    if return_url:
        params += f";c={return_url}"

    encoded = base64.b64encode(params.encode()).decode()
    base = settings.PAYME_CHECKOUT_BASE.rstrip("/")
    return f"{base}/{encoded}"


async def create_order(db: AsyncSession, user_id: int, plan_id: str) -> SubscriptionOrder:
    if plan_id not in PLAN_PRICES:
        raise ValueError(f"Noma'lum plan_id: {plan_id}")

    order = SubscriptionOrder(
        user_id=user_id,
        plan_id=plan_id,
        amount=PLAN_PRICES[plan_id],
        status=OrderStatus.PENDING,
    )
    db.add(order)
    await db.commit()
    await db.refresh(order)
    return order
