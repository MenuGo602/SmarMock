"""
Obuna buyurtmalari va Payme tranzaksiyalari uchun modellar.

DIQQAT: `Base`, `get_db` va `users.id` import yo'llarini Qism 1 (backend)
loyihangizdagi haqiqiy joylashuvga moslang. Bu fayl mustaqil namuna sifatida
yozilgan — to'g'ridan-to'g'ri mavjud `app/models.py` ichiga ko'chirib qo'yish
ham mumkin.
"""
import enum
from datetime import datetime

from sqlalchemy import (
    BigInteger, Column, DateTime, Enum as SAEnum, ForeignKey, Integer, String,
)
from sqlalchemy.orm import relationship

from app.database import Base  # noqa  ← loyihangizdagi declarative Base


class OrderStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    CANCELLED = "cancelled"


class TxState(int, enum.Enum):
    CREATED = 1
    PERFORMED = 2
    CANCELLED_AFTER_CREATE = -1
    CANCELLED_AFTER_PERFORM = -2


class SubscriptionOrder(Base):
    """Foydalanuvchi reja tanlaganda yaratiladigan to'lov niyati (order)."""

    __tablename__ = "subscription_orders"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    plan_id = Column(String(32), nullable=False)        # masalan: "pro", "premium"
    amount = Column(Integer, nullable=False)            # tiyin (1 so'm = 100 tiyin)
    status = Column(SAEnum(OrderStatus), default=OrderStatus.PENDING, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    transaction = relationship(
        "PaymeTransaction", back_populates="order", uselist=False
    )


class PaymeTransaction(Base):
    """Payme tomonidan yuborilgan har bir tranzaksiya holati."""

    __tablename__ = "payme_transactions"

    id = Column(Integer, primary_key=True)
    payme_id = Column(String(64), unique=True, index=True, nullable=False)
    order_id = Column(Integer, ForeignKey("subscription_orders.id"), nullable=False)
    amount = Column(Integer, nullable=False)
    state = Column(Integer, default=TxState.CREATED.value)
    reason = Column(Integer, nullable=True)
    create_time = Column(BigInteger, nullable=False)
    perform_time = Column(BigInteger, default=0)
    cancel_time = Column(BigInteger, default=0)

    order = relationship("SubscriptionOrder", back_populates="transaction")
