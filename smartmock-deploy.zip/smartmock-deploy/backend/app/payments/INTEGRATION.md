# Payme integratsiyasi — ulash bo'yicha qadamlar

Bu papka (`backend/app/payments/`) mustaqil modul sifatida yozilgan. Uni
Qism 1'dagi mavjud FastAPI loyihangizga ulash uchun quyidagi 5 qadamni bajaring.

## 1. Fayllarni ko'chiring

`app/payments/` papkasini backend repo'ingizdagi `app/` ichiga nusxalang.

## 2. Import yo'llarini moslang

Quyidagi fayllarda bor importlarni o'zingizning haqiqiy joylashuvga almashtiring:

- `app/payments/models.py` → `from app.database import Base`
- `app/payments/router.py` → `from app.database import get_db`
- `app/payments/payme_client.py` / `router.py` → `from app.config import settings`

Agar loyihangizda `Base`/`get_db` boshqa nomda bo'lsa (masalan `app.db.session`),
shu importlarni o'zgartiring — qolgan kod o'zgarmaydi.

## 3. Sozlamalarga Payme o'zgaruvchilarini qo'shing

`app/config.py` dagi `Settings` klassiga:

```python
PAYME_MERCHANT_ID: str = ""
PAYME_KEY: str = ""
PAYME_ACCOUNT_FIELD: str = "order_id"
PAYME_CHECKOUT_BASE: str = "https://checkout.test.paycom.uz"  # productionda: checkout.paycom.uz
```

Va `.env` ga tegishli qiymatlarni qo'shing (`.env.example` ga qarang).

## 4. Routerni ulang

`app/main.py` ichida:

```python
from app.payments import payme_router

app.include_router(payme_router, prefix="/api/v1")
```

Natijada webhook manzili: `https://api.yourdomain.com/api/v1/payments/payme`
— shuni Payme Business kabinetida "Kassa havolasi" (callback URL) sifatida ko'rsatasiz.

## 5. Mavjud `/subscriptions/subscribe` endpointini yangilang

Frontend (`api/index.ts`) va bot allaqachon shu shaklni kutadi:
`POST /subscriptions/subscribe {plan_id}` → `{payment_url}`. Endpoint tanasini
shunga almashtiring:

```python
from app.payments.payme_client import create_order, build_checkout_url
from app.payments.models import SubscriptionOrder  # agar kerak bo'lsa

@router.post("/subscriptions/subscribe")
async def subscribe(
    payload: SubscribeIn,
    user: User = Depends(current_user),
    db: AsyncSession = Depends(get_db),
):
    order = await create_order(db, user.id, payload.plan_id)
    payment_url = build_checkout_url(
        order_id=order.id,
        amount_tiyin=order.amount,
        return_url=settings.WEBAPP_URL,
    )
    return {"payment_url": payment_url}
```

## 6. Migratsiya

```bash
alembic revision --autogenerate -m "add payme tables"
alembic upgrade head
```

## 7. `/health` endpointi (agar yo'q bo'lsa)

Railway healthcheck uchun kerak:

```python
@app.get("/health")
async def health():
    return {"status": "ok"}
```

## 8. Test qilish

Payme test kabinetida (`merchant.test.paycom.uz`) test to'lov yarating va
quyidagi metodlarni tekshiring: `CheckPerformTransaction` → `CreateTransaction`
→ `PerformTransaction`. Har bir bosqichda `subscription_orders.status` va
`payme_transactions.state` qiymatlarini DB'da tekshiring.

Productionga o'tishda faqat `.env` dagi `PAYME_CHECKOUT_BASE`'ni
`https://checkout.paycom.uz` ga va `PAYME_KEY`'ni production kalitiga
almashtirish kifoya — kod o'zgarmaydi.
