# SmartMock AI — Qism 4: Docker + Railway Deploy + Payme To'lov

Bu qism Docker konteynerlashtirish, Railway'ga deploy va Payme orqali
obuna to'lovlarini qabul qilishni qamrab oladi.

## Loyiha tuzilmasi

```
smartmock-deploy/
├── docker-compose.yml        # LOKAL test uchun (Postgres + 3 servis)
├── .env.example               # Barcha servislar uchun umumiy o'zgaruvchilar
├── backend/
│   ├── Dockerfile
│   ├── railway.json
│   └── app/payments/           # YANGI — Payme moduli (mustaqil, ulash mumkin)
│       ├── models.py           # SubscriptionOrder, PaymeTransaction
│       ├── payme_client.py     # Checkout havola generatori
│       ├── router.py           # JSON-RPC webhook (6 metod)
│       ├── errors.py
│       └── INTEGRATION.md      # ← Qism 1 backendingizga ulash qadamlari
├── bot/
│   ├── Dockerfile
│   ├── railway.json
│   ├── utils/api_client.py     # YANGILANDI — create_subscription_order()
│   ├── keyboards/main_kb.py    # YANGILANDI — pay:pro / pay:premium callback
│   └── handlers/profile.py     # YANGILANDI — pay_selected handler
└── miniapp/
    ├── Dockerfile               # Multi-stage: Vite build → nginx serve
    ├── nginx.conf.template      # Railway $PORT bilan ishlaydi
    └── railway.json
```

**Eslatma:** `bot/` papkasida faqat 3 fayl o'zgartirildi (yuqorida belgilangan).
`bot.py`, `config.py`, `requirements.txt`, `handlers/start.py`, `handlers/exam.py`,
`handlers/results.py`, `middlewares/auth_middleware.py` — Qism 2'dagidek qoladi,
ularni shu papkaga shunchaki ko'chiring.

---

## 1. Qanday ishlaydi — to'lov oqimi

```
Foydalanuvchi bot'da "💳 Obuna" → reja tanlaydi (Pro/Premium)
  └→ bot backend'ga POST /subscriptions/subscribe {plan_id} yuboradi
       └→ backend: SubscriptionOrder yaratadi (status=pending)
            └→ Payme checkout havolasini generatsiya qiladi (base64 link)
  └→ bot foydalanuvchiga "💳 Payme orqali to'lash" tugmasini yuboradi (url=...)
       └→ foydalanuvchi Payme'da kartasini kiritadi va to'laydi
            └→ Payme backend'ga webhook yuboradi:
                 CheckPerformTransaction → CreateTransaction → PerformTransaction
                      └→ backend: order.status=paid, obuna faollashtiriladi
```

Frontend (Mini App) `SubscribePage` ham xuddi shu
`subscriptionApi.subscribe(planId)` chaqiruvini ishlatadi — backend javobi
bir xil (`{payment_url}`), shuning uchun u allaqachon ishlaydi. Agar
`SubscribePage` hali havolani ochmasa, tugma bosilganda shuni qo'shing:

```ts
const { payment_url } = await subscriptionApi.subscribe(planId);
window.Telegram?.WebApp?.openLink
  ? window.Telegram.WebApp.openLink(payment_url)
  : window.open(payment_url, "_blank");
```

## 2. Backendga ulash

To'liq qadamlar: `backend/app/payments/INTEGRATION.md`. Qisqacha:
1. `app/payments/` ni backend repo'ingizga ko'chiring
2. `Base`/`get_db`/`settings` importlarini moslang
3. `app/main.py`'da `app.include_router(payme_router, prefix="/api/v1")`
4. `/subscriptions/subscribe` endpointini yangilang
5. `alembic upgrade head`

## 3. Payme kabinetida sozlash

1. https://business.payme.uz — ro'yxatdan o'ting, kassa yarating
2. **Kassa havolasi (callback URL):** `https://api.yourdomain.com/api/v1/payments/payme`
3. Test rejimida `merchant.test.paycom.uz` orqali test to'lovlarini tekshiring
4. Productionga o'tishda `PAYME_KEY` va `PAYME_CHECKOUT_BASE`'ni ishlab chiqarish
   qiymatlariga almashtiring

## 4. Lokal test (Railway'ga yuklashdan oldin)

```bash
cp .env.example .env   # qiymatlarni to'ldiring
docker compose up --build
```

- Backend: http://localhost:8000/docs
- Mini App: http://localhost:5173
- Bot: Telegram'da `/start` yuboring (polling rejimida)

## 5. Railway'ga deploy

Railway'da **bitta repo, 3 ta alohida servis** yaratiladi (monorepo
yondashuvi — har birida "Root Directory" sozlanadi):

### 5.1. Postgres

Railway dashboard → **New → Database → PostgreSQL**. Railway avtomatik
`DATABASE_URL` o'zgaruvchisini beradi.

### 5.2. Backend servisi

1. **New → GitHub Repo** → shu repo'ni tanlang
2. **Settings → Root Directory** → `backend`
3. **Variables** → `.env.example` dagi backend o'zgaruvchilarini qo'shing,
   `DATABASE_URL` uchun Postgres pluginiga referens bering:
   `${{Postgres.DATABASE_URL}}`
4. Railway avtomatik `backend/Dockerfile`'ni topib build qiladi
5. **Settings → Networking → Generate Domain** → `api.yourdomain.com`
   (yoki custom domain ulang)

### 5.3. Bot servisi

1. Yangi servis → shu repo, **Root Directory** → `bot`
2. Variables: `BOT_TOKEN`, `API_BASE_URL=https://api.yourdomain.com/api/v1`, `WEBAPP_URL`
3. ⚠️ **Muhim:** `numReplicas` har doim **1** bo'lishi kerak (long polling —
   2 nusxa ishlasa Telegram "409 Conflict" xatosi beradi). Bu `railway.json`
   ichida allaqachon belgilangan.
4. Bot'ga ochiq domen kerak emas (u faqat tashqariga so'rov yuboradi)

### 5.4. Mini App servisi

1. Yangi servis → shu repo, **Root Directory** → `miniapp`
2. **Variables** → `VITE_API_URL=https://api.yourdomain.com/api/v1`
   (build-vaqtida kerak, Dockerfile `ARG` orqali oladi)
3. **Generate Domain** → `miniapp.yourdomain.com`
4. Shu domenni bot'ning `WEBAPP_URL` o'zgaruvchisiga qo'ying va @BotFather'da
   ham Menu Button / Web App URL sifatida o'rnating

### 5.5. Deploydan keyin tekshirish ro'yxati

- [ ] `https://api.yourdomain.com/health` → `200 OK`
- [ ] `https://miniapp.yourdomain.com` → ochiladi, API'ga ulanadi
- [ ] Bot loglarida `"Bot started ✅"` ko'rinadi, faqat 1 ta instance ishlayapti
- [ ] Payme test kabinetida test to'lov muvaffaqiyatli o'tadi
- [ ] `subscription_orders.status` to'lovdan keyin `paid` ga o'zgaradi

---

## Keyingi (ixtiyoriy, Qism 5 bo'lishi mumkin)

- Webhook rejimiga o'tish (polling o'rniga) — Railway'da bitta doimiy domen orqali
- Admin panel / statistik dashboard
- Click to'lov tizimini qo'shish (Payme bilan parallel)
