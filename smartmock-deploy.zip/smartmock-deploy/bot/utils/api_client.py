"""
Backend API bilan muloqot.

O'ZGARISH (Qism 4): `create_subscription_order` qo'shildi — Payme checkout
havolasini backend orqali generatsiya qilish uchun.
"""
import httpx
from config import settings


async def get_user_profile(telegram_id: int) -> dict | None:
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{settings.API_BASE_URL}/users/me",
                headers={"X-Telegram-Id": str(telegram_id)},
                timeout=5.0,
            )
            return resp.json() if resp.status_code == 200 else None
    except Exception:
        return None


async def get_user_attempts(telegram_id: int) -> list:
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{settings.API_BASE_URL}/attempts/my",
                headers={"X-Telegram-Id": str(telegram_id)},
                timeout=5.0,
            )
            return resp.json() if resp.status_code == 200 else []
    except Exception:
        return []


async def get_available_tests(level: str | None = None) -> list:
    try:
        params = {"level": level} if level else {}
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{settings.API_BASE_URL}/tests/",
                params=params,
                timeout=5.0,
            )
            return resp.json() if resp.status_code == 200 else []
    except Exception:
        return []


async def create_subscription_order(plan_id: str, jwt_token: str | None) -> dict | None:
    """
    Backend'da order yaratadi va Payme checkout havolasini qaytaradi.
    Javob shakli: {"payment_url": "https://checkout.paycom.uz/..."}
    """
    try:
        headers = {"Authorization": f"Bearer {jwt_token}"} if jwt_token else {}
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{settings.API_BASE_URL}/subscriptions/subscribe",
                json={"plan_id": plan_id},
                headers=headers,
                timeout=10.0,
            )
            return resp.json() if resp.status_code == 200 else None
    except Exception:
        return None
