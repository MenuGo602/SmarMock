"""
O'ZGARISH (Qism 4): `subscription_kb()` endi web_app statik linklar o'rniga
callback_data ishlatadi — chunki haqiqiy Payme checkout havolasi har bir
foydalanuvchi/order uchun backend tomonida DINAMIK generatsiya qilinadi
(profile.py dagi `pay_selected` handlerga qarang).
"""
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, WebAppInfo,
)
from config import settings


def main_menu_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="📋 Testlar"),
                KeyboardButton(text="📊 Natijalarim"),
            ],
            [
                KeyboardButton(
                    text="🌐 WebApp ochish",
                    web_app=WebAppInfo(url=settings.WEBAPP_URL)
                ),
            ],
            [
                KeyboardButton(text="💳 Obuna"),
                KeyboardButton(text="👤 Profil"),
            ],
        ],
        resize_keyboard=True,
        input_field_placeholder="Menyu tanlang...",
    )


def open_webapp_kb(page: str = "") -> InlineKeyboardMarkup:
    url = f"{settings.WEBAPP_URL}{'#' + page if page else ''}"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🚀 Ochish", web_app=WebAppInfo(url=url))
    ]])


def exam_levels_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🟢 A1 Beginner", callback_data="level:A1"),
            InlineKeyboardButton(text="🔵 A2 Elementary", callback_data="level:A2"),
        ],
        [
            InlineKeyboardButton(text="🟣 B1 Intermediate", callback_data="level:B1"),
            InlineKeyboardButton(text="🟠 B2 Upper Int.", callback_data="level:B2"),
        ],
    ])


def exam_mode_kb(level: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📝 Full Exam (barcha qismlar)",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}?level={level}&mode=full")
        )],
        [InlineKeyboardButton(
            text="🎯 Practice (qism tanlash)",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}?level={level}&mode=practice")
        )],
    ])


def results_kb(attempt_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📊 Batafsil ko'rish",
            web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/results/{attempt_id}")
        )],
        [
            InlineKeyboardButton(text="🔄 Qayta topshirish", callback_data=f"retry:{attempt_id}"),
            InlineKeyboardButton(text="🏠 Menyu", callback_data="menu"),
        ],
    ])


def subscription_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Pro — 145 000 so'm/oy", callback_data="pay:pro")],
        [InlineKeyboardButton(text="👑 Premium — 295 000 so'm/oy", callback_data="pay:premium")],
        [InlineKeyboardButton(text="ℹ️ Taqqoslash", callback_data="plans:compare")],
    ])


def back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="◀️ Orqaga", callback_data="menu")
    ]])
