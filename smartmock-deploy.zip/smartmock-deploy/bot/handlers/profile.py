"""
O'ZGARISH (Qism 4): `pay_selected` callback handleri qo'shildi — bosilganda
backend orqali order yaratiladi va haqiqiy Payme checkout havolasi yuboriladi.
"""
from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.filters import Command

from keyboards.main_kb import subscription_kb, open_webapp_kb
from utils.api_client import get_user_profile, create_subscription_order

router = Router()

LEVEL_PROGRESS = {"A1": 10, "A2": 30, "B1": 60, "B2": 85, "C1": 100}

PLAN_NAMES = {"pro": "⭐ Pro", "premium": "👑 Premium"}


def progress_bar(pct: int, length: int = 10) -> str:
    filled = round(pct / 100 * length)
    return "█" * filled + "░" * (length - filled)


@router.message(Command("profile"))
@router.message(F.text == "👤 Profil")
async def cmd_profile(message: Message):
    user_id = message.from_user.id
    profile = await get_user_profile(user_id)

    if not profile:
        name = message.from_user.full_name
        level = "B1"
        streak = 0
        tests_done = 0
        avg_score = 0
        plan = "Free"
    else:
        name = profile["full_name"]
        level = profile["level"]
        streak = profile["streak_days"]
        tests_done = profile["tests_done"]
        avg_score = profile["avg_score"]
        plan = profile["plan"].capitalize()

    pct = LEVEL_PROGRESS.get(level, 50)
    bar = progress_bar(pct)

    plan_emoji = {"Free": "🆓", "Pro": "⭐", "Premium": "👑"}.get(plan, "🆓")

    await message.answer(
        f"👤 <b>Profilim</b>\n\n"
        f"📛 Ism: <b>{name}</b>\n"
        f"🎓 Daraja: <b>{level}</b>\n"
        f"📈 Progress: [{bar}] {pct}%\n\n"
        f"🔥 Streak: <b>{streak} kun</b>\n"
        f"📝 Testlar: <b>{tests_done} ta</b>\n"
        f"📊 O'rtacha: <b>{avg_score}%</b>\n\n"
        f"💳 Obuna: {plan_emoji} <b>{plan}</b>",
        parse_mode="HTML",
        reply_markup=open_webapp_kb("dashboard"),
    )


@router.message(Command("subscribe"))
@router.message(F.text == "💳 Obuna")
async def cmd_subscribe(message: Message):
    await message.answer(
        "💳 <b>Obuna rejalari</b>\n\n"
        "🆓 <b>Free</b> — oyiga 2 ta test\n"
        "   • Lesen + Hören\n"
        "   • Asosiy natijalar\n\n"
        "⭐ <b>Pro</b> — 145 000 so'm/oy\n"
        "   • Cheksiz testlar\n"
        "   • Barcha 5 qism\n"
        "   • AI Writing baholash\n"
        "   • AI Speaking tahlil\n"
        "   • Batafsil statistika\n\n"
        "👑 <b>Premium</b> — 295 000 so'm/oy\n"
        "   • Pro dagi hamma narsa\n"
        "   • Shaxsiy o'qituvchi\n"
        "   • Haftalik online darslar\n"
        "   • Imtihon kafolati\n\n"
        "👇 Rejimni tanlang:",
        parse_mode="HTML",
        reply_markup=subscription_kb(),
    )


@router.callback_query(F.data == "plans:compare")
async def compare_plans(callback: CallbackQuery):
    await callback.message.edit_text(
        "📊 <b>Rejimlar taqqoslash</b>\n\n"
        "┌─────────────┬──────┬─────┬─────────┐\n"
        "│ Xususiyat   │ Free │ Pro │ Premium │\n"
        "├─────────────┼──────┼─────┼─────────┤\n"
        "│ Testlar/oy  │  2   │  ∞  │    ∞    │\n"
        "│ Lesen       │  ✅  │ ✅  │   ✅    │\n"
        "│ Hören       │  ✅  │ ✅  │   ✅    │\n"
        "│ Schreiben   │  ❌  │ ✅  │   ✅    │\n"
        "│ Sprechen    │  ❌  │ ✅  │   ✅    │\n"
        "│ AI baholash │  ❌  │ ✅  │   ✅    │\n"
        "│ Statistika  │  ❌  │ ✅  │   ✅    │\n"
        "│ O'qituvchi  │  ❌  │ ❌  │   ✅    │\n"
        "└─────────────┴──────┴─────┴─────────┘\n\n"
        "💰 Free: 0 so'm  |  Pro: 145 000 so'm  |  Premium: 295 000 so'm",
        parse_mode="HTML",
        reply_markup=subscription_kb(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("pay:"))
async def pay_selected(callback: CallbackQuery, jwt_token: str | None = None):
    """
    AuthMiddleware tomonidan `data["jwt_token"]` aiogram orqali shu handlerga
    kwarg sifatida uzatiladi (agar mavjud bo'lsa).
    """
    plan_id = callback.data.split(":")[1]

    order = await create_subscription_order(plan_id, jwt_token)
    if not order or "payment_url" not in order:
        await callback.answer(
            "⚠️ Hozircha to'lov tizimi ishlamayapti, keyinroq urinib ko'ring.",
            show_alert=True,
        )
        return

    plan_label = PLAN_NAMES.get(plan_id, plan_id)
    await callback.message.answer(
        f"💳 <b>{plan_label}</b> rejasiga obuna bo'lish uchun to'lovni yakunlang.\n\n"
        "Quyidagi tugma orqali Payme'ga o'tasiz. To'lov tasdiqlangach "
        "obunangiz avtomatik faollashadi.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="💳 Payme orqali to'lash", url=order["payment_url"])
        ]]),
    )
    await callback.answer()
